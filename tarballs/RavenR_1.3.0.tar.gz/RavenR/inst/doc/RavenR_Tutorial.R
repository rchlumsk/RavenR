## ---- eval=FALSE---------------------------------------------------------
#  # install.packages("devtools")
#  library(devtools)
#  devtools::install_github("rchlumsk/RavenR")

## ---- echo=TRUE, message=FALSE, warning=FALSE, results='hide'------------
library(RavenR)
ls("package:RavenR") # view all functions in RavenR

## ---- message=FALSE, warning=FALSE, results='hide'-----------------------
data(forcing.data)
?forcing.data

## ------------------------------------------------------------------------
# read in hydrograph sample csv data from RavenR package
ff <- system.file("extdata","run1_Hydrographs.csv", package="RavenR")

# read in sample rvi file from the RavenR package
rvi <- system.file("extdata", "Nith.rvi", package="RavenR")

