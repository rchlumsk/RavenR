## ----Installation of RavenR, eval=FALSE----------------------------------
#  # install.packages("devtools")
#  library(devtools)
#  devtools::install_github("rchlumsk/RavenR")

## ----RavenR Function List, echo=TRUE, message=FALSE, warning=FALSE, results='hide'----
library(RavenR)
ls("package:RavenR") # view all functions in RavenR

## ----R Sample Data, message=FALSE, warning=FALSE, results='hide'---------
data(forcing.data)
?forcing.data
data("hydrograph.data")
?hydrograph.data

## ----Raw Sample Data-----------------------------------------------------
# read in hydrograph sample csv data from RavenR package
ff <- system.file("extdata","run1_Hydrographs.csv", package="RavenR")

# read in sample rvi file from the RavenR package
rvi <- system.file("extdata", "Nith.rvi", package="RavenR")

## ----Forcings------------------------------------------------------------
ff <- system.file("extdata","run1_ForcingFunctions.csv",package="RavenR")
# ff <- "mydirectory/ForcingFunctions.csv" # replace with your own file
ff_data <- RavenR::forcings.read(ff)
head(ff_data$forcings[,1:6])

## ---- fig.height=10, fig.width=7-----------------------------------------
forcings.plot(ff_data$forcings)

## ----Hydrograph, fig.height=5, fig.width=6-------------------------------
ff <- system.file("extdata","run1_Hydrographs.csv",package="RavenR")
# ff <- "mydirectory/Hydrographs.csv" # replace with your own file
hy <- hyd.read(ff)
head(hy$hyd)
flow36 <- hyd.extract("Sub36",hy)
precip <- hyd.extract("precip",hy)$sim

## ---- fig.height=5, fig.width=6, message=FALSE, warning=FALSE------------
plot(lubridate::date(flow36$sim),flow36$sim,col='red',type='l')
lines(lubridate::date(flow36$obs),flow36$obs,col='black')

## ---- fig.height=5, fig.width=6------------------------------------------
hyd.plot(sim=flow36$sim, obs=flow36$obs, precip=precip)

## ----Spaghetti Plot, fig.height=5, fig.width=6---------------------------
flow.spaghetti(flow36$sim)
flowdurcurve.plot(flow36$sim)

## ---- fig.height=5, fig.width=6------------------------------------------
cum.plot.flow(flow36$sim, obs=flow36$obs)
annual.volume(flow36$sim, flow36$obs)

## ----Monthly Volume Bias, fig.height=5, fig.width=6----------------------
monthly.vbias(flow36$sim, obs=flow36$obs)

## ----Dygraphs, fig.height=5, fig.width=6---------------------------------
hyd.dyGraphs(hy, basins="Sub36")

## ----Subbasin Map Plot, fig.height=5, fig.width=6------------------------
# Raw sample data
shpfilename <- system.file("extdata","Nith_shapefile_sample.shp",package="RavenR")

# Custom Output data from Raven for Nith basin
cust.data <- custom.read(system.file("extdata","run1_PRECIP_Daily_Average_BySubbasin.csv",
                                     package="RavenR"))

subIDcol <- 'subID' # attriute in shapefile with subbasin IDs
plot.date <- "2003-03-30" # date for which to plot custom data

# function call
SBMap.plot(shpfilename,subIDcol,plot.date,cust.data)

## ---- fig.height=5, fig.width=6------------------------------------------
leg.title <- 'Legend \nPrecip. (mm)'
colour1 <- "white"
colour2 <- "cyan"
num.classes <- 8
plot.title <- 'Daily Average Precipitation (mm/d)'

# create an updated plot
SBMap.plot(shpfilename,subIDcol,plot.date,cust.data,plot.title=plot.title, 
           colour1 = colour1, colour2=colour2,
           leg.title = leg.title, num.classes=num.classes)

## ----echo=FALSE, fig.height=5, fig.width=6-------------------------------
cust.data <- custom.read(system.file("extdata","run1_SNOW_Daily_Average_BySubbasin.csv",
                                     package="RavenR"))
leg.title <- 'Legend \nSnowpack (mm)'
colour1 <- "grey40"
colour2 <- "white"
num.classes <- 5
plot.title <- 'Daily Average Snowpack (mm)'
plot.date <- "2003-03-01" # date for which to plot custom data

# create an updated plot
SBMap.plot(shpfilename,subIDcol,plot.date,cust.data,plot.title=plot.title, colour1 = colour1, colour2=colour2,
           leg.title = leg.title, normalize=T, num.classes=num.classes)


## ----echo=TRUE, eval=FALSE, fig.height=5, fig.width=6--------------------
#  cust.data <- custom.read(system.file("extdata","run1_SNOW_Daily_Average_BySubbasin.csv",
#                                       package="RavenR"))
#  leg.title <- 'Legend \nSnowpack (mm)'
#  colour1 <- "grey40"
#  colour2 <- "white"
#  num.classes <- 5
#  plot.title <- 'Daily Average Snowpack (mm)'
#  # Feel free to adjust the date range here, although many dates make this slow to run!
#  plot.daterange <- '2003-02-01/2003-03-30'
#  
#  gif.filename='Nith_snowpack_Feb2003_March2003.gif'
#  gif.speed <- 0.5
#  cleanup <- FALSE # see the individual plots in the scratch directory created
#  
#  SBMap.animate(shpfilename,subIDcol,plot.daterange,cust.data,plot.title=plot.title,
#                colour1 = colour1, colour2=colour2,
#                leg.title = leg.title, normalize=T, num.classes=num.classes,
#                gif.filename=gif.filename,
#                gif.speed=gif.speed, cleanup=cleanup
#             )
#  

## ----echo=TRUE, eval=FALSE, fig.height=5, fig.width=6--------------------
#  cust.data <- custom.read(system.file("extdata","run1_PRECIP_Daily_Maximum_BySubbasin.csv",
#                                       package="RavenR"))
#  leg.title <- 'Legend \nDaily Max Precip (mm)'
#  colour1 <- "white"
#  colour2 <- "blue"
#  num.classes <- 5
#  plot.title <- 'Daily Max Precip. (mm)'
#  plot.daterange <- '2003-05-01/2003-06-30'
#  
#  gif.filename='Nith_precip_May2003_June2003.gif'
#  gif.speed <- 0.5
#  cleanup <- FALSE
#  
#  SBMap.animate(shpfilename,subIDcol,plot.daterange,cust.data,plot.title=plot.title,
#                colour1 = colour1, colour2=colour2,
#                leg.title = leg.title, normalize=T, num.classes=num.classes,
#                gif.filename=gif.filename,
#                gif.speed=gif.speed, cleanup=cleanup
#             )
#  

## ---- results='hide'-----------------------------------------------------
ls("package:RavenR")

## ----Workflow Script, eval=FALSE-----------------------------------------
#  # Load the RavenR sample data
#  # =====================================================
#  indir <- "C:/temp/Nith/"
#  outdir <- "C:/temp/Nith/output/"
#  fileprefix <- "Nith"
#  
#  if (dir.exists(outdir)==FALSE) {
#    dir.create(outdir)
#  }
#  
#  setwd(outdir)
#  
#  # RUN RAVEN
#  # =====================================================
#  # writes complete command prompt command
#  # > Raven.exe [filename] -o [outputdir]
#  RavenCMD <-paste(indir,"Raven.exe ",indir,fileprefix," -o ",outdir,sep="")
#  system(RavenCMD) # this runs raven from the command prompt

## ----Save Plots, eval=FALSE----------------------------------------------
#  # GENERATE OUTPUT PLOTS
#  # =====================================================
#  # use the package data, or read in the model output files
#  
#  # ff_data <- forcings.read("ForcingFunctions.csv")
#  pdf("forcings.pdf") # create a pdf file to direct plot to
#  forcings.plot(ff_data$forcings)
#  dev.off() #finishes writing plot to .pdf file
#  
#  data(watershed.data)
#  mywshd <- watershed.data$watershed.storage
#  #mywshd <- RavenR::watershed.read("WatershedStorage.csv")$watershed.storage
#  png("snowpack.png") # create a png file to direct plot to
#  plot(mywshd$snow)
#  dev.off() #finishes writing plot to .png file

