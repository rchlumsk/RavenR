#' Extract function for Raven Hydrograph object
#'
#' hyd.extract is used for extracting data from the Raven hydrograph object.
#' Works for objects from hyd.extract function (from the Hydrographs.csv file).
#'
#' hyd.extract is used to extract the modelled and observed data from a Raven
#' hydrograph object by name reference. It is also easy to create plots of
#' modelled and observed data using this function. The simulated and observed
#' files are outputted regardless of whether a plot is created, for the
#' specified period.
#'
#' The subs input is the name of the column desired for use; the most common
#' use of this will be for subbasin outflows, where the names will be of the
#' form "subXX", for example "sub24".
#'
#' The hyd object is the full hydrograph object (hyd and units in one data
#' frame) created by the hyd.read function. Both the hyd and units are
#' required, since the units are placed onto the plots if one is created. This
#' is useful to at least see the units of the plotted variable, even if the
#' plot is later modified.
#'
#' The prd input is used to specify a period for the plot and/or the data
#' output. The period should be specified as a string start and end date, of
#' the format "YYYY-MM-DD/YYYY-MM-DD", for example, "2006-10-01/2010-10-01". If
#' no period is supplied, the entire time series will be used.
#'
#' @param subs column name for plotting/extracting
#' @param hyd full hydrograph data frame (including units) produced by hyd.read
#' @param prd time period for plotting, as string. See details
#' @return \item{sim}{model simulation for specified column and period}
#' \item{obs}{observed data for specified column and period}
#' \item{inflow}{inflow simulation for specified column and period}
#' @seealso \code{\link{hyd.read}} for reading in the Hydrographs.csv file and
#' creating the object required in this function.
#'
#' See also \href{http://www.civil.uwaterloo.ca/jrcraig/}{James R.
#' Craig's research page} for software downloads, including the
#' \href{http://www.civil.uwaterloo.ca/jrcraig/Raven/Main.html}{Raven page}
#' @keywords Raven plot extract hydrograph
#' @examples
#'
#' # set working directory to file location
#' dir <- "C:/temp/model/output"
#' setwd(dir)
#'
#' # create full file path
#' ff <- paste0(dir,"/","run4_Hydrographs.csv")
#'
#' # read in Raven Hydrographs file, store into myhyd
#' myhyd <- hyd.read(ff)
#'
#' # no plot or observed data, specified period
#' flow.24 <- hyd.extract(subs="sub24",hyd=myhyd,prd="2006-10-01/2010-10-01")
#'
#' # plot the simulated flow values
#' plot(flow.24$sim,col='red')
#' # plot observed values on same plot
#' lines(flow.24$obs,lty=5)
#'
#' # example for precipitation
#' myprecip <- hyd.extract(subs="precip",hyd=myhyd)
#'
#' @export hyd.extract
hyd.extract <- function(subs=NA, hyd=NA, prd=NULL) {
  
  if (missing(subs)) {
    stop("subs is required for this function.")
  }
  if (missing(hyd)) {
    stop("hyd is required for this function; please supply the full output file from hyd.read.")
  }
  
  # extract random pair
  hydrographs <- hyd$hyd
  units <- hyd$units
  mycols <- colnames(hydrographs)
  subID <- gsub("[^0-9]", "", subs)
  mysub.sim <- sprintf("\\b%s\\b",subs) # sim does not have a sim 
  mysub.obs <- sprintf("\\b%s_obs\\b",subs)
  mysub.inflow <- sprintf("\\b%s_inflow\\b",subs)
  # ind.base <- grep(mysub,mycols)
  # ind.sim <- ind.base[1]  # assume sim is always there and first
  # ind.inflow <- ind.base[grep(mysub.inflow,mycols[ind.base])]
  # ind.obs <- ind.base[grep(mysub.obs,mycols[ind.base])]
  
  ind.sim <- grep(mysub.sim,mycols)
  ind.obs <- grep(mysub.obs,mycols)
  ind.inflow <- grep(mysub.inflow,mycols)
  
  ind <- c(ind.sim,ind.inflow,ind.obs)
  
  if (length(ind)==0) {
    stop(sprintf("%s not found in the columns, check the supplied subs argument.",mysub))
  } else if (length(ind) > 3) {
    stop(sprintf("There are %i matches for %s, expect a maximum of 3.",length(ind),mysub))
  }
  
  # assume first column is always simulated one; observed or inflows follow afterwards
  # assume if all 3 columns exist, observed is the second one (obs before inflows)
  mysim <- NULL
  myobs <- NULL
  myinflow <- NULL
  
  if (length(ind.sim) == 1) {
    mysim <- hydrographs[,ind.sim]
  }
  if (length(ind.obs) == 1) {
    myobs <- hydrographs[,ind.obs]
  }
  if (length(ind.inflow) == 1) {
    myinflow <- hydrographs[,ind.inflow]
  }
  
  # determine the period to use
  if (!(is.null(prd))) {
    
    # prd is supplied; check that it makes sense
    firstsplit <- unlist(strsplit(prd,"/"))
    if (length(firstsplit) != 2) {
      stop("Check the format of supplied period argument prd; should be two dates separated by '/'.")
    }
    if (length(unlist(strsplit(firstsplit[1],"-"))) != 3 || length(unlist(strsplit(firstsplit[2],"-"))) != 3
        || nchar(firstsplit[1])!= 10 || nchar(firstsplit[2]) != 10) {
      stop("Check the format of supplied period argument prd; two dates should be in YYYY-MM-DD format.")
    }
    # add conversion to date with xts format check ?
    
  } else {
    # period is not supplied
    
    # not using smart.period function and no period supplied; use whole range
    N <- nrow(hydrographs)
    prd <- sprintf("%d-%02d-%02d/%i-%02d-%02d",year(hydrographs[1,1]),month(hydrographs[1,1]),day(hydrographs[1,1]),
                      year(hydrographs[N,1]),month(hydrographs[N,1]),day(hydrographs[N,1]) )
  }
  
  # return values
  return(list("sim" = mysim[prd,1], "obs" = myobs[prd,1],"inflow"=myinflow[prd,1]))
}

