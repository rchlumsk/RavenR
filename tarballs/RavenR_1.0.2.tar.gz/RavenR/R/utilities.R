
# utility functions that are very helpful

# basic utility functions ----
#######################

# function to clear the console and everything
# command name taken from Matlab similar function
# clc <- function() {
#   rm(list = ls()) # clear workspace
#   cat("\014")     # clear console
#   if (dev.cur() != 1) {
#     dev.off()       # close all plots
#   }
# }

# string manipulation functions ----
#######################

# tokenize function, similar to the one in Raven code
# input string read from file, chop into blocks without spaces or tabs
# also truncates anything after a comment character, #

# need to test this out and get it to work :(

# tokenize <- function(ss) {
#   line <- unlist(strsplit(ss,c('\t'," "),fixed=F))
#   line <- line[line != ""]
#   if (any(line == "#")) {
#     line <- line[1:(which(line=="#")[1]-1)]
#   }
#   return(line)
# }

# next four functions derived from post on this link
# http://stackoverflow.com/questions/7963898/extracting-the-last-n-characters-from-a-string-in-r

# obtain n characters from the right side of the string
substrRight <- function(x, n){
  substr(x, nchar(x)-n+1, nchar(x))
}

# obtain n characters from the left side of the string
substrLeft <- function(x, n){
  substr(x, 1,n)
}

# remove n characters from the right side of the string
substrMRight <- function(x, n){
  substr(x, 1,nchar(x)-n)
}

# remove n characters from the left side of the string
substrMLeft <- function(x, n){
  substr(x, n+1,nchar(x))
}

# time series utility function ----
#######################

# return months of year in short form or long form
months.year <- function(short=T) {
  if (short) {
    return(c('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'))
  } else {
    return(c('January','February','March','April','May','June','July',
             'August','September','October','November','December'))
  }
}

# HourlyToDaily = function(hourly)
# {
#   daily<-apply.daily(hourly,mean)
#   index(daily) <- round(index(daily)-82800,"day")
#   indexTZ(daily) = Sys.getenv("TZ")
#   return(daily)
# }


# returns the number of days between two dates, not inclusive
numDays <- function(date1,date2) {
  return( length(seq.Date(from=date1,to=date2,by=1))-1 )
}

# return the number of days in the month (actual), input as a Date
# obtained from: http://stackoverflow.com/questions/6243088/find-out-the-number-of-days-of-a-month-in-r
numDaysMonth <- function(date) {
  m <- format(date, format="%m")
  while (format(date, format="%m") == m) {
    date <- date + 1
  }
  return(as.integer(format(date - 1, format="%d")))
}

# returns function averaged for each month in the given series
# remove any month with less than n data points
apply.monthly.avg <- function(x,colid=1,full.tbl=F,min.points=1,FUN,...) {

  mos <- months.year()

  # calculate mean and std by month
  mt <- matrix(data=NA,nrow=12,ncol=2)
  rownames(mt) <- mos
  colnames(mt) <- c('fun.mean','fun.sd')

  minyear <- min(year(x))
  maxyear <- max(year(x))
  years <- seq(minyear,maxyear,1)

  fun.yearly <- matrix(ncol=length(years),nrow=12)
  colnames(fun.yearly) <- years
  rownames(fun.yearly) <- mos

  for (i in 1:length(years)) {
    for (j in 1:12) {
      dd <- x[,colid][year(time(x))==years[i] & month(time(x))==j]
      if (length(dd) > 0 & length(dd) >= min.points) {
        fun.yearly[j,i] <- apply(dd,2,FUN,...)
      }
    }
  }

  if (full.tbl) {
    return(fun.yearly)
  } else {

    for (i in 1:12) {
      mt[i,1] = mean(fun.yearly[i,], na.rm = TRUE)
      mt[i,2] = sd(fun.yearly[i,], na.rm = TRUE)
    }

    return(mt)
  }
}


### plotting utilities ----


# adds a transparency to any colour specified in plotting
# requires colour and transparency level, i.e. 200 (slightly transparent) to <10 (very transparent)
# from http://stackoverflow.com/questions/12995683/any-way-to-make-plot-points-in-scatterplot-more-transparent-in-r
addColTrans <- function(colour,trans)
{
  # This function adds transparancy to a colour.
  # Define transparancy with an integer between 0 and 255
  # 0 being fully transparant and 255 being fully visable
  # Works with either colour and trans a vector of equal length,
  # or one of the two of length 1.
  # from http://stackoverflow.com/questions/12995683/any-way-to-make-plot-points-in-scatterplot-more-transparent-in-r

  if (length(colour)!=length(trans)&!any(c(length(colour),length(trans))==1)) stop("Vector lengths not correct")
  if (length(colour)==1 & length(trans)>1) colour <- rep(colour,length(trans))
  if (length(trans)==1 & length(colour)>1) trans <- rep(trans,length(colour))

  num2hex <- function(x)
  {
    hex <- unlist(strsplit("0123456789ABCDEF",split=""))
    return(paste(hex[(x-x%%16)/16+1],hex[x%%16+1],sep=""))
  }
  rgb <- rbind(col2rgb(colour),trans)
  res <- paste("#",apply(apply(rgb,2,num2hex),2,paste,collapse=""),sep="")
  return(res)
}




