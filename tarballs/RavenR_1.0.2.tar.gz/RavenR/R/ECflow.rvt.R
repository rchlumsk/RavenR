
# convert EC stream gauge data into rvt file

# wish list:
# - report back the flags / handle data appropriately considering flags (not sure what that means exactly yet)
# - adds obs option to front of file


ECflow.rvt <- function(ff,subIDs,prd=NULL,stnNames=NULL,write.redirect=F,flip.number=F) {

  # data checks
  if (!(is.null(stnNames)) & (length(subIDs) != length(stnNames))) {
    stop("Length of subIDs must be the same as stnNames.")
  }

  # PARAMETERS
  # param (flow) == 1
  # param (level) == 2

  # SYMBOLS - not currently reported
  #

  # determine period ----
  # determine the period to use
  if (!(is.null(prd))) {

    # period is supplied; check that it makes sense
    firstsplit <- unlist(strsplit(prd,"/"))
    if (length(firstsplit) != 2) {
      stop("Check the format of supplied period; should be two dates separated by '/'.")
    }
    if (length(unlist(strsplit(firstsplit[1],"-"))) != 3 || length(unlist(strsplit(firstsplit[2],"-"))) != 3
        || nchar(firstsplit[1])!= 10 || nchar(firstsplit[2]) != 10) {
      stop("Check the format of supplied period; two dates should be in YYYY-MM-DD format.")
    }
  }

  # check the stations in the supplied file
  dd <- read.table(ff,sep=",",skip=1,header=T)

  # fix to handle multi-byte marker/byte order marker,
  #   appears if there is more than one station per file
  stns <- as.character(unique(iconv(dd$ID,to="ASCII")))
  stns <- stns[!(is.na(stns))]
  if (length(stns) != length(subIDs)) {
    stop(sprintf("Number of stations found in file not equal to the length of subIDs or stnNames, please check the
         supplied file and function inputs. Found %i stations, %s",length(stns),toString(paste(stns))))
  }

  # begin writing the support file
  if (write.redirect) {
    fc.redirect <- file('flow_stn_redirect_text.rvt',open='w+')
  }

  # iterate through for all stations in the file
  for (i in 1:length(stns)) {
    dd.temp <- dd[(dd$ID == stns[i] & dd$PARAM == 1),]
    # date.temp <- as.Date(dd.temp$Date,format="%Y/%m/%d")
    ts.temp <- xts(order.by=as.Date(dd.temp$Date,format="%Y/%m/%d"),x=dd.temp$Value)
    if (!(is.null(prd))) {
      ts.temp <- ts.temp[prd]
    }
    # change all NA values to Raven NA (-1.2345)
    ts.temp[is.na(ts.temp)] = -1.2345
    # check for empty time series
    if (nrow(ts.temp)==0) {
      close(fc.redirect)
      stop(sprintf("Empty time series for station %s, check the supplied period and/or the availability of flow data in the supplied file.",stns[i]))
    }

    # write .rvt file
    if (flip.number) {
      if (!(is.null(stnNames))) {
        rvt.name <- sprintf('%i_%s.rvt',subIDs[i],stns[i])
      } else {
        rvt.name <- sprintf('%i_%s.rvt',subIDs[i],stns[i])
      }
    } else {
      if (!(is.null(stnNames))) {
        rvt.name <- sprintf('%s_%i.rvt',stnNames[i],subIDs[i])
      } else {
        rvt.name <- sprintf('%s_%i.rvt',stns[i],subIDs[i])
      }
    }

    fc <- file(rvt.name,open='w+')
    writeLines(sprintf(':ObservationData HYDROGRAPH %i m3/s # %s',subIDs[i],rvt.name),fc)
    writeLines(sprintf('%s 00:00:00 1.0 %i',as.character(lubridate::date(ts.temp[1])),nrow(ts.temp)),fc)
    for (j in 1:nrow(ts.temp)) {
      writeLines(sprintf('%g',ts.temp[j]),fc)
    }
    writeLines(':EndObservationData',fc)
    close(fc)

    # write to support file
    if (write.redirect) {
      writeLines(sprintf(':RedirectToFile %s',rvt.name),fc.redirect)
    }
  }

  if (write.redirect) {
    close(fc.redirect)
  }
}

