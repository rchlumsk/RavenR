res.init <- function(ff=NA,initial.stage=0.0) {

  if (missing(ff)) {
    stop("ff as a file path to reservoir data is required for this function.")
  }

  if (initial.stage < 0 || initial.stage > 1) {
    stop("Initial stage must be between 0 and 1.")
  }

  res <- read.csv(ff,header=T)

  # initiate files
  fc2 <- file("initial_res_conditions.rvc.temp",open='w+a')
  writeLines(c('# Initial conditions for reservoirs in a Raven model','# Copy + Paste these lines into the rvc file','#'),fc2)

  subbasins <- unique(res[,1])

  for (i in 1:length(subbasins)) {
    dd <- res[res[,1] == subbasins[i],]

    stage <- dd[,2]
    writeLines(sprintf(':InitialReservoirStage  %i  %.2f',subbasins[i],min(stage)+initial.stage*(max(stage)-min(stage))),fc2)
  }
  close(fc2)
}
