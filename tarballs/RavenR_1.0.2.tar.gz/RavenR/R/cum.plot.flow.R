
# cumulative flow plot
# assumes daily flows in units of cms

cum.plot.flow <- function(sim=NULL,obs=NULL,inflow=NULL) {

  sec.per.day <- 86400
  cum.sim <- NULL ; cum.obs <- NULL ; cum.inflow <- NULL

  # get the indicies of water years
  ep <- wyear.indices(sim)

  cum.sim <- matrix(NA,nrow=nrow(sim))
  for (k in 1:(length(ep)-1)) {
    cum.sim[(ep[k]):(ep[k+1])] <- cumsum(sim[(ep[k]):(ep[k+1])])
  }
  cum.sim <- cum.sim*sec.per.day

  if (!(is.null(obs))) {
    cum.obs <- matrix(NA,nrow=nrow(obs))
    for (k in 1:(length(ep)-1)) {
      cum.obs[(ep[k]):(ep[k+1])] <- cumsum(obs[(ep[k]):(ep[k+1])])
    }
    cum.obs <- cum.obs*sec.per.day
  }

  if (!(is.null(inflow))) {
    cum.inflow <- matrix(NA,nrow=nrow(obs))
    for (k in 1:(length(ep)-1)) {
      cum.inflow[(ep[k]):(ep[k+1])] <- cumsum(inflow[(ep[k]):(ep[k+1])])
    }
    cum.inflow <- cum.inflow*sec.per.day
  }

  max.vol <- max(cum.sim,cum.obs,cum.inflow,na.rm=T)*1.1

  plot(lubridate::date(sim),cum.sim,type='l',col='red',ylim=c(0,max.vol),
       ylab='Cumulative Flow [m3]',xlab='Date',lty=1)

  if (!(is.null(obs))) {
    lines(lubridate::date(sim),cum.obs,col='black',lty=3)
  }
  if (!(is.null(inflow))) {
    lines(lubridate::date(sim),cum.inflow,col='blue',lty=5)
  }

  # add a legend
  if (is.null(inflow) & is.null(obs) ) {
    # legend for only sim
    legend(
      x='topleft',
      c('sim'),
      col=c('red'),
      cex=0.7,inset=0.01,
      lty=c(1)
    )
  } else if ( is.null(inflow) & !(is.null(obs))) {
    # legend for sim and obs
    legend(
      x='topleft',
      c('sim','obs'),
      col=c('red','black'),
      cex=0.7,inset=0.01,
      lty=c(1,3)
    )
  } else if ( !(is.null(inflow)) & is.null(obs)) {
    # legend for sim and inflow
    legend(
      x='topleft',
      c('sim','inflow'),
      col=c('red','blue'),
      cex=0.7,inset=0.01,
      lty=c(1,5)
    )
  } else {
    # legend for all 3
    legend(
      x='topleft',
      c('sim','obs','inflow'),
      col=c('red','black','blue'),
      cex=0.7,inset=0.01,
      lty=c(1,3,5)
    )
  }
}
