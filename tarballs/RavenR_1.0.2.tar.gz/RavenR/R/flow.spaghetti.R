
# creates a spaghetti plot of flow values in the series provided
# assumes daily flows of cms

flow.spaghetti <- function(flow,include.legend=T,colour.wheel=T) {
  
  # initial plot setup
  ticks.at <- seq(1,366,1)
  ticks.seq <- c(seq(274,366,1),seq(1,273,1))
  ind.start <- seq(1,366,31)
  nyears <- round(nrow(flow)/365)
  ep <- wyear.indices(flow)
  y.min <- min(flow)
  y.max<-max(flow)
  
  # define colours to use
  # eventually want to update this to get it to pick 'nice' colours consistently
  if (colour.wheel) {
    cw <- sample(colours(), nyears,replace=F)
  } else {
    cw <- rep('black',nyears)
  }
  
  ## start plot
  if (include.legend) {
    .pardefault <- par(no.readonly=T)
    par(mar=c(5,4,4,4)+0.1)
    par(xpd=T)
  }
  plot(ticks.at,rnorm(366),xaxt='n',ylim=c(y.min,y.max),col='white',
       ylab='Flow [m3/s]',xlab='Day of Year')
  axis(1, at=ticks.at[ind.start],labels=ticks.seq[ind.start],cex.axis=0.7)
  
  j = 1
  for (i in 1:(length(ep)-1)) {
    temp <- coredata(flow[ep[i]:ep[i+1],])
    temp <- temp[1:(length(temp)-1)]
    lines(seq(1,length(temp),1),temp,lty=5,col=cw[j])
    j = j+1
  }
  
  # add legend
  if (include.legend) {
    labs <- matrix(ncol=1,nrow=j-1)
    
    # re-obtain periods and year labels; don't need for starting point
    labs <- lubridate::year(flow[ep])[-1]
    legend(x=380,y=y.max,legend=labs,bty='n',col=cw,lty=rep(5,length(labs)),cex=0.8)
    par(.pardefault)
  }
}

