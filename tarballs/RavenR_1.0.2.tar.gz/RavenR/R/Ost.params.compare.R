
Ost.params.compare <- function(ffs=NULL,num.metrics=NA,find.dev=F,num.sd=1) {
  
  # basic checks
  if (is.null(ffs)) {
    stop("ffs is required to have at least two different parameter sets to compare")
  }
  N <- length(ffs)
  for (i in 1:N) {
    if (!(file.exists(ffs[i]))) {
      stop(sprintf("File %s cannot be found",ffs[i]))
    }
  }
  if (num.metrics < 1 & !(is.na(floor(num.metrics)))) { stop("Cannot have less than 1 metric; check num.metrics.")}
  
  
  # create vector of data objects
  # assume same dimensions for each
  Ost.data <- read.table(ffs[1],header=T)
  if (!(is.na(floor(num.metrics)))) {
    Ost.data <- Ost.data[,-(3:(floor(num.metrics)+2))] # remove metrics aside from obj function
  }
  Ost.data <- Ost.data[,-1]
  best <- Ost.data[Ost.data[,1] == max(Ost.data[,1]),]
  n <- length(best)
  cc <- colnames(Ost.data)
  
  # array for holding data
  # array(NA,c(n,m,N))
  mat <- matrix(NA,nrow=N,ncol=n)
  
  # collect all data
  for (i in 1:N) {
    Ost.data <- read.table(ffs[i],header=T)
    # remove metrics
    if (!(is.na(floor(num.metrics)))) {
      Ost.data <- Ost.data[,-(3:(floor(num.metrics)+2))] # remove metrics aside from obj function
    }
    # remove run
    Ost.data <- Ost.data[,-1]
    # obtain the best trial
    best <- as.numeric(Ost.data[Ost.data[,1] == max(Ost.data[,1]),])
    # assign into structure
    mat[i,] <- best
  }
  
  # create data frame
  df <- data.frame(mat)
  colnames(df) <- cc
  
  # analyze
  paramstats <- matrix(NA,ncol=n,nrow=2)
  rownames(paramstats) <- c('mean','sd')
  colnames(paramstats) <- cc
  paramstats[1,] <- apply(df,2,mean)
  paramstats[2,] <- apply(df,2,sd)
  
  # combine
  ret <- rbind(df,paramstats)
  
  # find parameters with large variation
  if (find.dev) {
    
    # function to test if any params outside of one standard deviation
    myfunc <- function(xx,u,s) {
      if (any(abs(xx) > u+s*num.sd)) { return(TRUE)}
      return(FALSE)
    }
    
    test <- vector("logical",n)
    for (i in 1:n) {
      test[i] <- myfunc(ret[(1:N),i],ret[(1+N),i],ret[(2+N),i])
    }
    
    # find any that tested TRUE
    ind <- which(test)
  }
  
  if (find.dev) {
    return(list("Ost.data" = ret,"dev.ind"=ind))
  } else {
    return("Ost.data" = ret)
  }
  
}
