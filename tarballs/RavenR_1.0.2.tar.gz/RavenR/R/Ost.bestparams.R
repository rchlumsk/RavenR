
# returns the best X lines from OstModel0.txt, based on obj function
# option to remove all the non-obj function metrics
# option to remove the run number - good for formatting directly into a SOM or similar clustering algorithm

Ost.bestparams <- function(Ost.data=NA,best.num=0.1,num.metrics=NA,remove.run=T) {

  # get Ostrich data
  if (is.null(nrow(Ost.data))) {
    if (file.exists('OstModel0.txt')) {
      warning("Using OstModel0.txt in current folder, Ost.data not supplied")
      Ost.data <- read.table('OstModel0.txt',header=T)
    } else {
      stop("Ost.data is required and no OstModel0.txt file found in current folder")
    }
  }

  # basic checks
  if (num.metrics < 1 & !(is.na(floor(num.metrics)))) { stop("Cannot have less than 1 metric; check num.metrics.")}
  N <- nrow(Ost.data)
  if (best.num > nrow(Ost.data)) {stop("best.num is greater than the number of calibration trials")}
  if (best.num < 0) { stop("best.num must be positive")}


  # get best trials
  if (!(is.na(floor(num.metrics)))) {
    Ost.data <- Ost.data[,-(3:(floor(num.metrics)+2))] # remove metrics aside from obj function
    Ost.data.sorted <- Ost.data[order(Ost.data$obj.function),]
  } else {
    Ost.data.sorted <- Ost.data[order(Ost.data$obj.function),]
  }

  if (remove.run) {
    Ost.data.sorted <- Ost.data.sorted[,-1]
  }

  if (best.num < 1) {
    best.trials <- Ost.data.sorted[1:(floor(N*best.num)),]
  } else {
    best.trials <- Ost.data.sorted[1:floor(best.num),]
  }

  return("Ost.bestruns" = best.trials)
}
