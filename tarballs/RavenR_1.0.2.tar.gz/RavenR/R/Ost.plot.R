
Ost.plot <- function(Ost.data=NA,plot.type='oft',return.data=F,logy=F,rangey=NA,num.metrics=1,param.index=1) {
  
  # get Ostrich data
  if (is.null(nrow(Ost.data))) {
    if (file.exists('OstModel0.txt')) {
      warning("Using OstModel0.txt in current folder, Ost.data not supplied")
      Ost.data <- read.table('OstModel0.txt',header=T)
    } else {
      stop("Ost.data is required and no OstModel0.txt file found in current folder")
    }
  }
  
  # basic checks
  if (num.metrics < 1) { stop("Cannot have less than 1 metric; check num.metrics.")}
  if (param.index < 1) { stop("Cannot have less than 1 parameter; check param.index")}
  if (!(is.na(rangey)) && length(rangey) != 2) {stop("rangey must be of length 2, if supplied.")}
  
  if (plot.type == 'oft') {
    
    if (logy) {
      if (is.na(rangey)) {
        plot(Ost.data$Run,Ost.data$obj.function,
             xlab='Trial',ylab='Objective Function',
             log="y")
      } else {
        if (rangey[1] <= 0) {stop("Y range not valid for a log range")}
        plot(Ost.data$Run,Ost.data$obj.function,
             xlab='Trial',ylab='Objective Function',
             log="y", ylim=rangey)
      }
      
    } else {
      if (is.na(rangey[1])) {
        plot(Ost.data$Run,Ost.data$obj.function,
             xlab='Trial',ylab='Objective Function')
      } else {
        plot(Ost.data$Run,Ost.data$obj.function,
             xlab='Trial',ylab='Objective Function',
             ylim=rangey)
      }
      title('Objective Function v Trial',cex.main=1)
    }
  } else if (plot.type == 'boft') {
    ### create plot of best obj function vs trial
    
    # need to evaluate the best of each trial
    best.obj <- rep(NA,nrow(Ost.data))
    best.obj[1] <- Ost.data$obj.function[1]
    best <- best.obj[1]
    for (i in 2:nrow(Ost.data)) {
      if (Ost.data$obj.function[i] < best) {
        best = Ost.data$obj.function[i]
      }
      best.obj[i] = best
    }
    
    # create plot of best obj function vs trial
    if (logy) {
      plot(Ost.data$Run,best.obj,ylim=rev(range(best.obj)),
           xlab='Trial',ylab='Best Objective Function',
           type='l',log='y')
    } else {
      plot(Ost.data$Run,best.obj,ylim=rev(range(best.obj)),
           xlab='Trial',ylab='Best Objective Function',
           type='l')
    }
    title('Best Objective Function v Trial',cex.main=1)
    
  } else if (plot.type == 'psa') {
    ### create SA plot for a given parameter
    cols <- colnames(Ost.data)
    col.num <- 3 + num.metrics + param.index # reference for parameter column
    
    plot(Ost.data[,col.num],Ost.data$obj.function,
         ylab='Objective Function',xlab=cols[col.num],
         main='Marginal Parameter Sensitivty',cex.main=1)
  } else {
    stop("Plot type not recognized.")
  }
  
  # supplement data with the best obj vector
  if (return.data) {     Ost.data <- data.frame(Ost.data,best.obj)   }
  
}
