
# calculates/plots tthe monthly volume bias
# assumes daily flows of cms
# calculates for the water year
# can turn off plot with rplot=F; in this case will just return the
  # annual volume biases in m3 or unitless if normalzied

monthly.vbias <- function(sim,obs,rplot=T,add.line=T,normalize=T,add.labels=T) {

  obs.monthly <- apply.monthly(obs,sum,na.rm=T)
  sim.monthly <- apply.monthly(sim,sum,na.rm=T)
  mvbias <- matrix(NA,nrow=12,ncol=1)
  colnames(mvbias) <-c ("mvbias")
  rownames(mvbias) <- months.year(T)

  # important part - calculate monthly differences, relative or not
  if (normalize) {
    diff <- (sim.monthly - obs.monthly)/obs.monthly*100
    ylabel <- '% Flow Volume Bias'
  } else {
    diff <- (sim.monthly - obs.monthly)
    ylabel <- 'Flow Volume Bias [m3/s]'
  }

  # calculate mvbias (normalized or unnormalized handled the same)
  for ( k in 1:12) {
    mvbias[k] <- mean(diff[month(diff) == k,],na.rm=T)
  }

  # create plot
  if (rplot) {
    # thick line plot, maybe upgrade to bar plot eventually
    plot(mvbias,type='h',main='',xlab='Month',xaxt='n',ylab=ylabel,
         lwd=5,panel.first=grid())
    axis(1, at=1:12,labels=RavenR::months.year(T),cex.axis=0.6)
    if (add.line) { abline(h=0,lty=5) }
    if (add.labels) {
      if (max(mvbias,na.rm=T)/2 > 0 ) {
        mtext('overestimated',side=4,at=c(max(mvbias,na.rm=T)/2),cex=0.8)
      }
      if (min(mvbias,na.rm=T)/2 < 0 ) {
        mtext('underestimated',side=4,at=c(min(mvbias,na.rm=T)/2),cex=0.8)
      }
    }
  }
  return(mvbias)
}
