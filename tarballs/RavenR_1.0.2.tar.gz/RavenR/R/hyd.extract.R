

# extracts a flow time series from the Hydrographs object generated object

hyd.extract <- function(subs=NA, hyd=NA, period=NULL) {

  if (missing(subs)) {
    stop("subs is required for this function.")
  }
  if (missing(hyd)) {
    stop("hyd is required for this function; please supply the full output file from hyd.read.")
  }

  # extract random pair
  hydrographs <- hyd$hyd
  units <- hyd$units
  mycols <- colnames(hydrographs)
  subID <- gsub("[^0-9]", "", subs)
  mysub <- subs # sprintf("\\b%s\\b",subs)
  mysub.obs <- "obs"
  mysub.inflow <- "inflow"
  ind.base <- grep(mysub,mycols)
  ind.sim <- ind.base[1]  # assume sim is always there and first
  ind.inflow <- ind.base[grep(mysub.inflow,mycols[ind.base])]
  ind.obs <- ind.base[grep(mysub.obs,mycols[ind.base])]
  ind <- c(ind.sim,ind.inflow,ind.obs)

  if (length(ind)==0) {
    stop(sprintf("%s not found.",mysub))
  } else if (length(ind) > 3) {
    stop(sprintf("There are %i matches for %s, expect a maximum of 3.",length(ind),mysub))
  }

  # assume first column is always simulated one; observed or inflows follow afterwards
  # assume if all 3 columns exist, observed is the second one (obs before inflows)
  mysim <- NULL
  myobs <- NULL
  myinflow <- NULL

  if (length(ind.sim) == 1) {
    mysim <- hydrographs[,ind.sim]
  }
  if (length(ind.obs) == 1) {
    myobs <- hydrographs[,ind.obs]
  }
  if (length(ind.inflow) == 1) {
    myinflow <- hydrographs[,ind.inflow]
  }

  # determine the period to use
  if (!(is.null(period))) {

    # period is supplied; check that it makes sense
    firstsplit <- unlist(strsplit(period,"/"))
    if (length(firstsplit) != 2) {
      stop("Check the format of supplied period; should be two dates separated by '/'.")
    }
    if (length(unlist(strsplit(firstsplit[1],"-"))) != 3 || length(unlist(strsplit(firstsplit[2],"-"))) != 3
        || nchar(firstsplit[1])!= 10 || nchar(firstsplit[2]) != 10) {
      stop("Check the format of supplied period; two dates should be in YYYY-MM-DD format.")
    }
    # add conversion to date with xts format check ?

  } else {
    # period is not supplied

    # not using smart.period function and no period supplied; use whole range
    N <- nrow(hydrographs)
    period <- sprintf("%d-%02d-%02d/%i-%02d-%02d",year(hydrographs[1,1]),month(hydrographs[1,1]),day(hydrographs[1,1]),
                      year(hydrographs[N,1]),month(hydrographs[N,1]),day(hydrographs[N,1]) )
  }

  # return values
  return(list("sim" = mysim[period,1], "obs" = myobs[period,1],"inflow"=myinflow[period,1]))
}

