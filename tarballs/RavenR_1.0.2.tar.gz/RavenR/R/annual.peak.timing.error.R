

# calculates the difference in days between sim and obs peaks
# assumes daily flow data in units of cms

annual.peak.timing.error <- function(sim,obs,rplot=T,add.line=T,add.labels=T) {

  # calculate the maximum observed in each year
  max.obs <- apply.wyearly(obs, max,na.rm=T)
  dates <- max.obs[,1]
  max.obs <- max.obs[,2]

  # get the date of peak obs event
  max.obs.dates <- apply.wyearly(obs, function(x) sprintf("%i-%i-%i",lubridate::year(x[which.max(x),]),lubridate::month(x[which.max(x),]),lubridate::day(x[which.max(x),])))
  max.obs.dates <- as.character(max.obs.dates[,2])

  ind.obs <- matrix(NA,nrow=length(max.obs),ncol=1)
  for (k in 1:length(max.obs)) {
    ind.obs[k] <- which(year(obs)==year(max.obs.dates[k]) & month(obs)==month(max.obs.dates[k]) & day(obs)==day(max.obs.dates[k]))
  }

  # calculate the maximum simulated in each year
  max.sim <- apply.wyearly(sim, max,na.rm=T)
  max.sim <- max.sim[,2]

  # get the date of peak sim event
  max.sim.dates <- apply.wyearly(sim, function(x) sprintf("%i-%i-%i",lubridate::year(x[which.max(x),]),lubridate::month(x[which.max(x),]),lubridate::day(x[which.max(x),])))
  max.sim.dates <- as.character(max.sim.dates[,2])

  ind.sim <- matrix(NA,nrow=length(max.sim),ncol=1)
  for (k in 1:length(max.sim)) {
    ind.sim[k] <- which(year(sim)==year(max.sim.dates[k]) & month(sim)==month(max.sim.dates[k]) & day(sim)==day(max.sim.dates[k]))
  }

  errs <- ind.sim-ind.obs
  text.labels <- year(dates)

  if (rplot) {
    x.lab <- "Date (Water year ending)"
    y.lab <- "Day Difference in Peaks"
    title.lab <- ''
    if (add.line) {
      y.max <- max(0.5,max(errs))
      y.min <- min(-0.5,min(errs))
    } else {
      y.max <- max(errs)
      y.min <- min(errs)
    }
    plot(errs, xlab=x.lab, ylab=y.lab, main=title.lab,xaxt='n',ylim=c(y.min,y.max))
    if (add.line) { abline(h=0,lty=2) }
    axis(1, at=index(errs),labels=text.labels)

    if (add.labels) {
      if (max(errs,na.rm=T)/2 > 0 ) {
        mtext('late peak',side=4,at=c(max(errs,na.rm=T)/2),cex=0.8)
      }
      if (min(errs,na.rm=T)/2 < 0 ) {
        mtext('early peak',side=4,at=c(min(errs,na.rm=T)/2),cex=0.8)
      }
    }

  }
  df <- data.frame("date.end"=dates,"peak.timing.errors"=errs)
  return("df.peak.timing.error"=df)
}

