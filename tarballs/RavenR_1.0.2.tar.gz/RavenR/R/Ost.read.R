Ost.read <- function(ff='OstModel0.txt') {
  if(file.exists(ff)) {
    Ost.dd <- read.table(ff,header=T)
  } else { stop(sprintf("Cannot find file %s :( Check your current directory and file name.",ff))}
  return(Ost.dd)
}
