
# plots a scatterplot of the simulated and observed flows
# optionally add a 1:1 line
# optionally calcualtes R2 and adds to plot
# assumes units of cms
# accepts sim and obs as xts objects

# note that no title is added to the plot so that a title can be added afterwards, if
#   the plot is specific to a particular subbasin, location, iteration, etc.

flow.scatterplot <- function(sim,obs,add.line=T,add.r2=F,axis.zero=T) {
  x.lab <- "Observed flow [m3/s]"
  y.lab <- "Simulated flow [m3/s]"
  max.flow <- max(obs, sim,na.rm=T)
  if (axis.zero) {
    min.flow <- 0
  } else {
    min.flow <- min(obs, sim,na.rm=T)
  }
  plot(coredata(obs), coredata(sim), xlim=c(min.flow,max.flow), ylim=c(min.flow,max.flow),
       xlab=x.lab, ylab=y.lab)
  if (add.line) {
    abline(0,1, lty=2)
  }
  if (add.r2) {
    # check the calculation to ensure it is R2 with no intercept
    r2 <- 1 - (sum((obs-sim)^2,na.rm=T)/sum((obs-mean(obs,na.rm=T))^2,na.rm=T))
    mtext(sprintf('R2 = %.2f',r2), side=3,adj=1)
  }
}
