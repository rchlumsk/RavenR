
# calculates/plots the annual peak event errors
# assumes daily flows of cms
# calculates for the water year
# can turn off plot with rplot=F; in this case will just return the annual volumes in m3

annual.peak.event.error <- function(sim,obs,rplot=T,add.line=T,add.labels=T) {

  # obtain peak from annual.peak.event function
  df.peak.event <- annual.peak.event(sim,obs,rplot=F)

  # calculate the errors
  errs <- (df.peak.event$sim.peak.event - df.peak.event$obs.peak.event)/df.peak.event$obs.peak.event*100
  text.labels <- year(df.peak.event$date.end)

  if (rplot) {
    x.lab <- "Date (Water Year Ending)"
    y.lab <- "% Error in Event Peaks"
    title.lab <- ''
    if (add.line) {
      y.max <- max(0.5,max(errs))
      y.min <- min(-0.5,min(errs))
    } else {
      y.max <- max(errs)
      y.min <- min(errs)
    }
    plot(errs, xlab=x.lab, ylab=y.lab, main=title.lab,xaxt='n',ylim=c(y.min,y.max))
    axis(1, at=index(errs),labels=text.labels)
    if (add.line) { abline(h=0,lty=2) }
    if (add.labels) {
      if (max(errs,na.rm=T)/2 > 0 ) {
        mtext('overpredict',side=4,at=c(max(errs,na.rm=T)/2),cex=0.8)
      }
      if (min(errs,na.rm=T)/2 < 0 ) {
        mtext('underpredict',side=4,at=c(min(errs,na.rm=T)/2),cex=0.8)
      }
    }
  }
  df <- data.frame("date.end"=df.peak.event$date.end,"errors"=errs)
  return("df.peak.event.error"=df)
}
