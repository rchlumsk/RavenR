

# script for reading in Raven rvh files, compiling information, calcualating the 
#   drainage area for each subbasin
# assumes two lines after each header section of :SubBasins and :HRUs, no comments in these sections

calc.areas.rvh <- function(ff,calc.da=T,write.file=F,iter.thresh=NA) {
  
  if (missing(ff)) { stop("Requires rvh file as ff")}
  
  if (!(file.exists(ff))) { stop("Requires valid filepath to rvh file; check ff")}
  
  txt <- readLines(ff)
  
  # read in subbasin data
  sub.ind <- grep(':SubBasins',txt)
  sub.ind.end <- grep(':EndSubBasins',txt)
  sub.rvh <- matrix(NA,nrow=(sub.ind.end-sub.ind-3),ncol=4)
  colnames(sub.rvh) <- c('sub','downstr_sub','area_km2','drain_area_km2')
  sub.rvh.count = 1
  for (i in ((sub.ind+3):(sub.ind.end-1))) {
    
    line <- unlist(strsplit(txt[i],c('\t',' ')))
    line <- line[line != ""]
    
    sub.rvh[sub.rvh.count,] = as.numeric(c(line[1],line[3],NA,NA))
    sub.rvh.count <- sub.rvh.count + 1
  }
  
  # read in HRU data
  hru.ind <- grep(':HRUs',txt)
  hru.ind.end <- grep(':EndHRUs',txt)
  hru.rvh <- matrix(NA,nrow=(hru.ind.end-hru.ind-3),ncol=3)
  colnames(hru.rvh) <- c('hru','subID','area_km2')
  hru.rvh.count = 1
  for (i in ((hru.ind+3):(hru.ind.end-1))) {
    
    line <- unlist(strsplit(txt[i],c('\t',' ')))
    line <- line[line != ""]
    
    hru.rvh[hru.rvh.count,] = as.numeric(c(line[1],line[6],line[2]))
    hru.rvh.count <- hru.rvh.count + 1
  }
  
  # combine subbasin data and total areas
  for (i in 1:nrow(sub.rvh)) {
    temp <- which(hru.rvh[,2] == sub.rvh[i,1])
    tot.area <- sum(hru.rvh[temp,3])
    sub.rvh[i,3] <- tot.area
  }
  
  ### calculate all drainage areas
  
  if (calc.da) {
  
    # assign drainage_area = area in all headwater basins
    for (i in 1:nrow(sub.rvh)) {
      
      drains.to <- which(sub.rvh[,2] == sub.rvh[i,1])
      
      if (length(drains.to) == 0) {
        sub.rvh[i,4] <- sub.rvh[i,3]  
      }
    }
    
    # compute all remaining drainage areas iteratively
    
    iter.count <- 0
    if (is.na(iter.thresh)) { iter.thresh <- nrow(sub.rvh)*10 }
     # max number of iterations as 10*number_subs by default, failsafe if sub not found
    
    # continue script as long as there are uncalculated drainage areas
    while(any(is.na(sub.rvh[,4]))) {
      
      for (i in 1:nrow(sub.rvh)) {
        
        # if the drainage_area is NA, try to calculate
        if (is.na(sub.rvh[i,4])) {
          
          # find which basins drain into this one
          drains.to <- which(sub.rvh[,2] == sub.rvh[i,1])
          
          # check if their drainage areas have not been calculated
          # if not, then calculate this drainage area
          if (!(any(is.na(sub.rvh[drains.to,4])))) {
            sub.rvh[i,4] <- sum(sub.rvh[drains.to,4]) + sub.rvh[i,3]
          }
        }
      }
      
      iter.count <- iter.count + 1
      
      if (iter.count > iter.thresh) { 
        warning(sprintf("Iteration limit exceeded %i iterations; check rvh file for extra comments or broken links.",iter.thresh)) 
        break
      }
    }
  }
  
  if (write.file) {
    # write sub.rvh to file
    write.csv(sub.rvh, file=sprintf('%s_calculated_areas.csv',strsplit(ff,'.rvh')[[1]]),row.names=F,quote=F)
  }
  
  return("areas.rvh" = sub.rvh)
}
