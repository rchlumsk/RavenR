

# hydrological utilities ----
# many basic diagnostics provided by Nick Sgro
#######################


# returns the indices for the water year in time series object
# assumes October 1st as the start of the water year
# will return October 1st or September 30th indices, i.e. if time series ends on a September 30th date

wyear.indices <- function(sim) {
  temp <- sim[((month(sim[,1]) == 10) & (day(sim[,1]) == 1)) | ((month(sim[,1]) == 9) & (day(sim[,1]) == 30))]
  ep <- match(lubridate::date(temp),lubridate::date(sim))
  # remove all the unneccesary Sept 30th indices
  ind <- rep(0,length(ep))
  for (k in 1:(length(ep)-1)) {
    if ((ep[k+1]-ep[k])==1) {
      ind[k]=1
    }
  }
  ep <- cbind(ep,ind)[ind==0,1]
  return("wyear.ind"=ep)
}

# returns the indices for the water year in time series object, using definition from Australia
# assumes July 1st as the start of the water year
# will return July 1st or June 30th indices, i.e. if time series ends on a June 30th date

wyear.indices.aus <- function(sim) {
  temp <- sim[((month(sim[,1]) == 7) & (day(sim[,1]) == 1)) | ((month(sim[,1]) == 6) & (day(sim[,1]) == 30))]
  ep <- match(lubridate::date(temp),lubridate::date(sim))
  # remove all the unneccesary June 30th indices
  ind <- rep(0,length(ep))
  for (k in 1:(length(ep)-1)) {
    if ((ep[k+1]-ep[k])==1) {
      ind[k]=1
    }
  }
  ep <- cbind(ep,ind)[ind==0,1]
  return("wyear.ind"=ep)
}

# returns the indices for the specific start to the water year (custom definition)
# does not search for the day before or after

wyear.indices.custom <- function(sim,mm,dd) {
  temp <- sim[((month(sim[,1]) == mm) & (day(sim[,1]) == dd))]
  ep <- match(lubridate::date(temp),lubridate::date(sim))
  return("wyear.ind"=ep)
}


# apply function wrapper for the water year
# assumes an Oct 1st start to water year (finds Sept 30th if no Oct 1st)
# outputs function result with end date of water year

# single vector use
apply.wyearly <- function(x,FUN,...) {
  temp <- x[((month(x[,1]) == 10) & (day(x[,1]) == 1)) | ((month(x[,1]) == 9) & (day(x[,1]) == 30))]
  ep <- match(lubridate::date(temp),lubridate::date(x))

  # remove all the unneccesary Sept 30th indices
  ind <- rep(0,length(ep))
  for (i in 1:(length(ep)-1)) {
    if ((ep[i+1]-ep[i])==1) {
      ind[i]=1
    }
  }
  ep <- cbind(ep,ind)[ind==0,1]
  res <- xts::period.apply(x, ep, FUN, ...)
  # res <- period.apply(x, ep, sum)

  return(data.frame("date.end"=(lubridate::date(x)[ep])[2:length(ep)],"fun"=res))
}

# iterate for columns
  # required for some functions, such as max, which will otherwise take the max of the entire matrix
apply.wyearly.cols <- function(x,FUN,...) {

  if (missing(x)) {
    stop("Requires x object")
  }
  temp <- apply.wyearly(x[,1],FUN,...)
  # temp <- apply.wyearly(x[,1],sum)

  N <- nrow(temp)
  M <- ncol(x)
  dates <- temp[,1]
  mm <- matrix(NA,ncol=M,nrow=N)
  for (i in 1:M) {
    mm[,i] <- apply.wyearly(x[,i],FUN,...)[,2]
    # mm[,i] <- apply.wyearly(x[,i],sum)[,2]
  }
  ret <- data.frame(dates,mm)
  colnames(ret) <- c('date.end',colnames(x))
  return(ret)
}



# diagnostic functions contributed by Nick Sgro ----
# to be reviewed and added in future iterations of RavenR

# TotalVolume.gof= function(sim,obs)
# {
#   return(sum(sim)-sum(obs))
# }
#
# TotalVolumeProp.gof= function(sim,obs)
# {
#   return((sum(sim)-sum(obs))/sum(obs))
# }
#
# AR1Q= function(Q)
# {
#   #difQ<-Q-mean(Q)
#   #numer<-sum( difQ[-1]*difQ[-length(difQ)] )
#   #denom<-sum( (Q-meanQ)^2 )
#   #return( numer/denom )
#   return( ar(as.numeric(Q), order.max = 1)$ar )
# }
#
# LogMeanQ= function(Q)
# {
#   return( mean(log(Q)) )
# }
#
# LogSdQ= function(Q)
# {
#   return( sd(log(Q)) )
# }
#
# FDCSlope= function(Q, low=0.2, high=0.7, ranks=NULL)
# {
#   if(class(ranks)=="NULL")
#   {
#     ranks<-fdc(Q, plot=F)
#   }
#
#   QMid<-Q[ranks>low & ranks<high]
#   QHigh<-max(QMid)
#   QLow<-min(QMid)
#
#   return( log(QHigh)-log(QLow) )
# }
#
# FDCHigh= function(Q, level=0.2, ranks=NULL)
# {
#   if(class(ranks)=="NULL")
#   {
#     ranks<-fdc(Q, plot=F)
#   }
#   QHigh<-Q[ranks<level]
#
#   return( sum(QHigh) )
# }
#
# FDCLow= function(Q, level=0.7, ranks=NULL)
# {
#   if(class(ranks)=="NULL")
#   {
#     ranks<-fdc(Q, plot=F)
#   }
#   QLow<-Q[ranks>level]
#   QMin<-min(QLow)
#   return( sum(log(QLow)-log(QMin)) )
# }
#
# RunoffRatio= function(Q,P)
# {
#   return(sum(Q)/sum(P))
# }
#
# LogRunoffRatio= function(Q,P)
# {
#   return(sum(log(Q))/sum(P))
# }
#
# #######
# Signatures= function(sim,obs)
# {
#   sim.ranks<-1-(rank(as.numeric(sim))/(length(sim)+1))
#   obs.ranks<-1-(rank(as.numeric(obs))/(length(obs)+1))
#   simSigs<-c(mean(sim),sd(sim),median(sim),LogMeanQ(sim),LogSdQ(sim),AR1Q(sim),FDCSlope(sim,ranks=sim.ranks),FDCHigh(sim,ranks=sim.ranks),FDCLow(sim,ranks=sim.ranks))
#   obsSigs<-c(mean(obs),sd(obs),median(obs),LogMeanQ(obs),LogSdQ(obs),AR1Q(obs),FDCSlope(obs,ranks=obs.ranks),FDCHigh(obs,ranks=obs.ranks),FDCLow(obs,ranks=obs.ranks))
#   sigs<-(simSigs-obsSigs)/obsSigs*100
#   names(sigs)<-c('Mean', 'Stdev', 'median', 'Log Mean', 'Log Stdev', 'AR1', 'FDC Slope', 'FDC High', 'FDC Low')
#   return(sigs)
# }
#
# # calculate monthly volumes
# # use sim and obs as xts object
# MonthlyVolume.gof = function(sim,obs)
# {
#   sim.monthly<-apply.monthly(sim, mean)
#   obs.monthly<-apply.monthly(obs, mean)
#
#   bias.monthly<-as.numeric(lapply(0:11, function(x) pbias(sim.monthly[.indexmon(sim.monthly)==x], obs.monthly[.indexmon(obs.monthly)==x])))
#   error.monthly<-as.numeric(lapply(0:11, function(x) sum(abs(sim.monthly[.indexmon(sim.monthly)==x]-obs.monthly[.indexmon(obs.monthly)==x])/sum(obs.monthly[.indexmon(obs.monthly)==x])*100)))
#
#   gof.month <- t(data.frame(bias.monthly,error.monthly))
#   colnames(gof.month) <- RobBox::months.year()
#
#   return(gof.month)
# }
#
# YearlyVolume.gof = function(sim,obs)
# {
#   obs.ts<-as.numeric(index(obs[2]))-as.numeric(index(obs[1])) #timestep in seconds
#   obs.Yearly<-apply.yearly(obs,sum)*obs.ts
#
#   sim.ts<-as.numeric(index(sim[2]))-as.numeric(index(sim[1])) #timestep in seconds
#   sim.Yearly<-apply.yearly(sim,sum)*sim.ts
#
#   bias.Yearly<-pbias(sim.Yearly, obs.Yearly)
#   error.Yearly<-sum(abs(sim.Yearly-obs.Yearly))/sum(obs.Yearly)*100
#   r2.Yearly<-cor(sim.Yearly, obs.Yearly, method="pearson", use="pairwise.complete.obs")^2
#   rmse.Yearly<-rmse(sim.Yearly, obs.Yearly)
#
#   gof.Yearly<- c(bias.Yearly,error.Yearly,r2.Yearly,rmse.Yearly)
#   names(gof.Yearly)<- c("%bias","%error","R2", "rmse")
#
#   return(gof.Yearly)
# }
#
# NSE.gof= function(sim,obs, high=0.5, low=0.5)
# {
#   if(class(sim)[1]!="xts" | class(obs)[1]!="xts"){return(NULL)}
#
#   cutoff.high<-quantile(obs, high)
#   cutoff.low<-quantile(obs, low)
#   rising<-c(T, as.numeric(obs[-1])-as.numeric(obs[-length(obs)]) >=0)
#
#   NSE.total<-NSE(sim,obs)
#   NSE.high<- NSE(sim[obs>cutoff.high], obs[obs>cutoff.high])
#   NSE.low<- NSE(log(sim[obs<cutoff.low]), log(obs[obs<cutoff.low]))
#   NSE.summer<-NSE(sim[.indexmon(sim) %in% 4:8], obs[.indexmon(obs) %in% 4:8])
#   NSE.winter<-NSE(sim[.indexmon(sim) %in% c(0,1,2,3,9,10,11)], obs[.indexmon(obs) %in% c(0,1,2,3,9,10,11)])
#   NSE.rising<-NSE(sim[obs>cutoff.high & rising], obs[obs>cutoff.high & rising])
#   NSE.falling<-NSE(sim[obs>cutoff.high & !rising], obs[obs>cutoff.high & !rising])
#   RSR<-rsr(sim,obs)
#   PBIAS<- pbias(sim,obs)
#   R2<- cor(sim,obs, method='pearson')
#
#   gof.NSE<-c(NSE.total,NSE.high,NSE.low,NSE.summer,NSE.winter,NSE.rising,NSE.falling,RSR,PBIAS,R2)
#   names(gof.NSE)<-c('Total', 'High', 'Low', 'Summer', 'Winter', 'Rising', 'Falling','RSR', 'PBias', 'R2')
#
#   return(gof.NSE)
# }
#
# FSVolume.gof = function(sim,obs)
# {
#   sim.FS<-sim[.indexmon(sim)%in%1:8]
#   obs.FS<-obs[.indexmon(obs)%in%1:8]
#
#   obs.ts<-as.numeric(index(obs[2]))-as.numeric(index(obs[1])) #timestep in seconds
#   obs.FS<-apply.yearly(obs.FS,sum)*obs.ts
#
#   sim.ts<-as.numeric(index(sim[2]))-as.numeric(index(sim[1])) #timestep in seconds
#   sim.FS<-apply.yearly(sim.FS,sum)*sim.ts
#
#   bias.FS<-pbias(sim.FS, obs.FS)
#   r2.FS<-cor(sim.FS, obs.FS, method="pearson", use="pairwise.complete.obs")^2
#   rmse.FS<-rmse(sim.FS, obs.FS)
#
#   gof.FS<- c(bias.FS,r2.FS,rmse.FS)
#   names(gof.FS)<- c("%bias","R2", "rmse")
#
#   return(gof.FS)
# }

# --------

