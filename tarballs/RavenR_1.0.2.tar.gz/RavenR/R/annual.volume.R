
# calculates/plots the annual volumes
# assumes daily flows of cms
# calculates for the water year
# can turn off plot with rplot=F; in this case will just return the annual volumes in m3

annual.volume <- function(sim,obs,rplot=T,add.line=T,add.r2=F,axis.zero=F) {

  sec.per.day <- 86400

  #calculate the sums
  sum.sim <- apply.wyearly(sim, sum,na.rm=T)
  dates <- sum.sim[,1]
  sum.sim <- sum.sim[,2]
  sum.obs <- apply.wyearly(obs, sum,na.rm=T)[,2]

  # unit conversion
  sum.sim <- sum.sim*sec.per.day
  sum.obs <- sum.obs*sec.per.day

  # calculate the r2 fit
  if (add.r2) {
    # need to check the r2 calculation, ensure it is for an intercept of zero
    sum.obs.mean <- mean(sum.obs)
    ss.err <- sum((sum.sim - sum.obs)^2)
    ss.tot <- sum((sum.obs - sum.obs.mean)^2)
    r2 <- 1- ss.err/ss.tot
  }

  if (rplot) {
    x.lab <- "Observed Volume [m3]"
    y.lab <- "Simulated Volume [m3]"
    title.lab <- '' # "Annual Volume Comparison"
    if (axis.zero) {
      x.lim=c(0,max(sum.obs,sum.sim,na.rm=T)*1.1)
      y.lim=c(0,max(sum.obs,sum.sim,na.rm=T)*1.1)
    } else {
      x.lim=c(min(sum.obs,sum.sim,na.rm=T)*0.9,max(sum.obs,sum.sim,na.rm=T)*1.1)
      y.lim=c(min(sum.obs,sum.sim,na.rm=T)*0.9,max(sum.obs,sum.sim,na.rm=T)*1.1)
    }

    text.labels <- year(dates)
    plot(coredata(sum.obs), coredata(sum.sim), xlim=x.lim, ylim=y.lim, xlab=x.lab, ylab=y.lab, main=title.lab)
    text(coredata(sum.obs), coredata(sum.sim), text.labels, cex=0.75, pos=3)
    if (add.line) { abline(0,1,lty=2) }
    if (add.r2) {  mtext(sprintf('R2 = %.2f',r2), side=3,adj=1) }
  }
  df <- data.frame("date.end"=dates,"sim.vol"=sum.sim,"obs.vol"=sum.obs)
  return("df.volume"=df)
}
