
# calculates/plots the annual peaks at observed events
# assumes daily flows of cms
# calculates for the water year
# can turn off plot with rplot=F; in this case will just return the annual volumes in m3

annual.peak.event <- function(sim,obs,rplot=T,add.line=T,add.r2=F,axis.zero=F) {
  
  # calculate the maximum observed in each year
  max.obs <- apply.wyearly(obs, max,na.rm=T)
  dates <- max.obs[,1]
  max.obs <- max.obs[,2]
  
  # get the date of peak obs event
  max.obs.dates <- apply.wyearly(obs, function(x) sprintf("%i-%i-%i",lubridate::year(x[which.max(x),]),lubridate::month(x[which.max(x),]),lubridate::day(x[which.max(x),])))
  max.dates <- as.character(max.obs.dates[,2])
  
  ind <- matrix(NA,nrow=length(max.obs),ncol=1)
  for (k in 1:length(max.obs)) {
    ind[k] <- which(year(obs)==year(max.dates[k]) & month(obs)==month(max.dates[k]) & day(obs)==day(max.dates[k]))
  }
  # get the simulated values at those indices
  max.sim <- as.numeric(sim[ind])
  
  # calculate the r2 fit
  if (add.r2) {
    # need to check the r2 calculation, ensure it is for an intercept of zero
    max.obs.mean <- mean(max.obs)
    ss.err <- sum((max.sim - max.obs)^2)
    ss.tot <- sum((max.obs - max.obs.mean)^2)
    r2 <- 1- ss.err/ss.tot
  }
  
  if (rplot) {
    
    x.lab <- "Observed Peak Event [m3/s]"
    y.lab <- "Simulated Peak Event [m3/s]"
    title.lab <- '' #"Annual Peak Event Flow Comparison"
    if (axis.zero) {
      x.lim=c(0,max(max.obs,max.sim,na.rm=T)*1.1)
      y.lim=c(0,max(max.obs,max.sim,na.rm=T)*1.1)
    } else {
      x.lim=c(min(max.obs,max.sim,na.rm=T)*0.9,max(max.obs,max.sim,na.rm=T)*1.1)
      y.lim=c(min(max.obs,max.sim,na.rm=T)*0.9,max(max.obs,max.sim,na.rm=T)*1.1)
    }
    text.labels <- sprintf("'%02d",as.numeric(format(index(max.sim), format = "%Y")) )
    plot(coredata(max.obs), coredata(max.sim), xlim=x.lim, ylim=y.lim, xlab=x.lab, ylab=y.lab, main=title.lab)
    text(coredata(max.obs), coredata(max.sim), text.labels, cex=0.75, pos=3)
    if (add.line) { abline(0,1,lty=2) }
    if (add.r2) {  mtext(sprintf('R2 = %.2f',r2), side=3,adj=1) }
  }
  df <- data.frame("date.end"=dates,"sim.peak.event"=max.sim,"obs.peak.event"=max.obs)
  return("df.peak.event"=df)
}
