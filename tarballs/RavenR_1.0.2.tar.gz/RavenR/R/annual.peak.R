
# calculates/plots the annual peaks
# assumes daily flows of cms
# calculates for the water year
# can turn off plot with rplot=F; in this case will just return the annual volumes in m3

annual.peak <- function(sim,obs,rplot=T,add.line=T,add.r2=F,axis.zero=F) {

  # calculate the maximums
  max.sim <- apply.wyearly(sim, max,na.rm=T)
  dates <- max.sim[,1]
  max.sim <- max.sim[,2]
  max.obs <- apply.wyearly(obs, max,na.rm=T)[,2]

  # calculate the r2 fit
  if (add.r2) {
    # need to check the r2 calculation, ensure it is for an intercept of zero
    max.obs.mean <- mean(max.obs)
    ss.err <- sum((max.sim - max.obs)^2)
    ss.tot <- sum((max.obs - max.obs.mean)^2)
    text.labels <- year(dates)
    r2 <- 1- ss.err/ss.tot
  }

  if (rplot) {

    x.lab <- "Observed Peak [m3/s]"
    y.lab <- "Simulated Peak [m3/s]"
    title.lab <- '' #"Annual Peak Flow Comparison"
    if (axis.zero) {
      x.lim=c(0,max(max.obs,max.sim,na.rm=T)*1.1)
      y.lim=c(0,max(max.obs,max.sim,na.rm=T)*1.1)
    } else {
      x.lim=c(min(max.obs,max.sim,na.rm=T)*0.9,max(max.obs,max.sim,na.rm=T)*1.1)
      y.lim=c(min(max.obs,max.sim,na.rm=T)*0.9,max(max.obs,max.sim,na.rm=T)*1.1)
    }
    text.labels <- sprintf("'%02d",as.numeric(format(index(max.sim), format = "%Y")) )
    plot(coredata(max.obs), coredata(max.sim), xlim=x.lim, ylim=y.lim, xlab=x.lab, ylab=y.lab, main=title.lab)
    text(coredata(max.obs), coredata(max.sim), text.labels, cex=0.75, pos=3)
    if (add.line) { abline(0,1,lty=2) }
    if (add.r2) {  mtext(sprintf('R2 = %.2f',r2), side=3,adj=1) }
  }
  df <- data.frame("date.end"=dates,"sim.peak"=max.sim,"obs.peak"=max.obs)
  return("df.peak"=df)
}
