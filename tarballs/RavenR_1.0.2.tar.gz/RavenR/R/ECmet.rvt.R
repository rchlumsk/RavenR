
# convert EC meteorological data files into Raven rvt files
# appends to all files rather than overwrite ( just in case case function is used in a loop )

# prd - period for plotting, YYYY-MM-DD/YYYY-MM-DD format
# stnName - name for the climate station to override the one in the .csv file
# forcing.set - set of forcings to include in the rvt file
# met.prefix - prefix the file name with "met_"
# write.redirect - write to file the :RedirectToFile commands for the main .rvt climate data file
# write.stndata - write to file the Raven formatted gauge data (i.e. name, lat/long, elev, :Redirect)
# perform.qc - perform quality control on the data. Not yet available


ECmet.rvt <- function(ff,prd=NULL,stnName=NULL,forcing.set=1,met.prefix=T,write.redirect=F,write.stndata=F,perform.qc=F) {

  # eventually want to update to handle multiple files from different stations,
  #   and spit everything out nicely
  # for now just assume all input files are for the same station, and ignore those that are not
  # handling different stations will require creating a vector of R objects, a bit more complicated
  ##################################
  # all.climateIDs = NULL
  # rvt.obj <- setClass('metobj',slots=c(stnName='character',climateID='integer',dd='POSIXct'))
  # rvt.object.list <- list()

  # forcing.set
  # 1 = precip, daily max temp, daily min temp
  # 2 = rain, snow, daily max temp, daily min temp

  # hardcoded file names for optional printouts
  rd.file <- 'met_redirects.rvt'
  stndata.file <- 'met_stndata.rvt'

  # assumed hardcoded column indices for the rr.ts object (see below)
  max.temp.ind <- 1
  min.temp.ind <- 2
  mean.temp.ind <- 3
  tot.rain.ind <- 6
  tot.snow.ind <- 7
  tot.precip.ind <- 8

  if (perform.qc) {
    warning("Sorry, quality control not available yet.")
  }

  # check number of files to read in
  if (length(ff) == 0 ) {
    stop("Requires at least one file to read in.")
  }

  # check format of the prd argument
  if (!(is.null(prd))) {

    # period is supplied; check that it makes sense
    firstsplit <- unlist(strsplit(prd,"/"))
    if (length(firstsplit) != 2) {
      stop("Check the format of supplied period; should be two dates separated by '/'.")
    }
    if (length(unlist(strsplit(firstsplit[1],"-"))) != 3 || length(unlist(strsplit(firstsplit[2],"-"))) != 3
        || nchar(firstsplit[1])!= 10 || nchar(firstsplit[2]) != 10) {
      stop("Check the format of supplied period; two dates should be in YYYY-MM-DD format.")
    }
  }

  # read in file first, locate data row indices
  rr <- readLines(ff[1],n=50)
  sname.ind <- grep("Station Name",rr,fixed=TRUE)
  lat.ind <- grep("Latitude",rr,fixed=TRUE)
  long.ind <- grep("Longitude",rr,fixed=TRUE)
  elev.ind <- grep("Elevation",rr,fixed=TRUE)
  climateID.ind <- grep("Climate Identifier",rr,fixed=TRUE)
  dt.ind <- grep("Date/Time",rr,fixed=TRUE)

  # re-read as csv file, parse metadata
  rr <- readLines(ff[1],n=dt.ind-1)
    # find rr by index, take out extra characters and replace spaces with underscores
  sname <- gsub(" ","_",gsub("\"","",unlist(strsplit(rr[sname.ind],","))[2]))
    # consider setting the sname to lower case, although can be overwritten by the stnName argument
  climateID <- as.numeric(gsub("\"","",unlist(strsplit(rr[climateID.ind],","))[2]))
  lat <- as.numeric(gsub("\"","",unlist(strsplit(rr[lat.ind],","))[2]))
  long <- as.numeric(gsub("\"","",unlist(strsplit(rr[long.ind],","))[2]))
  elev <- as.numeric(gsub("\"","",unlist(strsplit(rr[elev.ind],","))[2]))

  # parse data in file
  rr <- read.table(ff[1],header=T,sep = ",", quote = "\"",  dec = ".",skip=dt.ind-1,stringsAsFactors=F)
  find.time=F
  if (any(grepl("Time",colnames(rr)[2:5]))) {
    dd <- as.POSIXct(paste(rr$Year,rr$Month,rr$Day,rr$Time,sep="-"),format="%Y-%m-%d %H:%M:%S")
    find.time=T
  } else {
    dd <- as.POSIXct(paste(rr$Year,rr$Month,rr$Day,sep="-"),format="%Y-%m-%d")
  }
  if (find.time) {
    rr <- rr[,-c(1:6)]
  } else {
    rr <- rr[,-c(1:5)]
  }

  # create time series - very dependent on format, check this here
  rr.ts <- xts(x=rr[,seq(1,19,by=2)],order.by=dd)

  # determine timestep in data
  timestep <- as.numeric(as.difftime(as.Date(dd[2])-as.Date(dd[1]),units='days'))

  if (timestep != 1) {
    stop("Function not available yet for non-daily timesteps.")
  }

  # replace missing data / qaqc
    # to be filled

  # iterate for other files in ff -----
  if (length(ff) > 1) {

    for (i in 2:length(ff)) {
      # read in file first, locate data row indices
      rr <- readLines(ff[i],n=50)
      climateID.ind <- grep("Climate Identifier",rr,fixed=TRUE)
      dt.ind <- grep("Date/Time",rr,fixed=TRUE)

      # re-read as csv file, parse metadata
      rr <- readLines(ff[i],n=dt.ind-1)
      # find rr by index, take out extra characters and replace spaces with underscores
      climateID.temp <- as.numeric(gsub("\"","",unlist(strsplit(rr[climateID.ind],","))[2]))

      if (climateID.temp == climateID) {

        # parse data in file
        rr <- read.table(ff[i],header=T,sep = ",", quote = "\"",  dec = ".",skip=dt.ind-1,stringsAsFactors=F)
        find.time=F
        if (any(grepl("Time",colnames(rr)[2:5]))) {
          dd <- as.POSIXct(paste(rr$Year,rr$Month,rr$Day,rr$Time,sep="-"),format="%Y-%m-%d %H:%M:%S")
          find.time=T
        } else {
          dd <- as.POSIXct(paste(rr$Year,rr$Month,rr$Day,sep="-"),format="%Y-%m-%d")
        }
        if (find.time) {
          rr <- rr[,-c(1:6)]
        } else {
          rr <- rr[,-c(1:5)]
        }

        # create time series - very dependent on format, check this here
        rr.ts.temp <- xts(x=rr[,seq(1,19,by=2)],order.by=dd)

        # determine timestep in data
        timestep.temp <- as.numeric(as.difftime(as.Date(dd[2])-as.Date(dd[1]),units='days'))

        if (timestep == timestep.temp) {
          # merge time series together
          rr.ts <- rbind(rr.ts, rr.ts.temp)

        } else {
          warning(sprintf("Timestep is different from base file in %s, file ignored.",ff[i]))
        }

      } else {
        warning(sprintf("Diffferent Climate identifier from first file in %s, file ignored",ff[i]))
      }

    }
  }

  # additional xts manipulations -----

    # check if the time series is missing any dates
  if (length(seq.Date(from=lubridate::date(rr.ts[1]),to=lubridate::date(rr.ts[nrow(rr.ts)]),by=1)) != nrow(rr.ts)) {
    stop("Gap exists in the dates of the supplied files; please supply a continuous set of met data. Rvt files not written.")
  }

  # generate prd if not supplied
  if (is.null(prd)) {
    N <- nrow(rr.ts)
    prd <- sprintf("%d-%02d-%02d/%i-%02d-%02d",year(rr.ts[1,1]),month(rr.ts[1,1]),day(rr.ts[1,1]),
                   year(rr.ts[N,1]),month(rr.ts[N,1]),day(rr.ts[N,1]) )
  }

  # adjust rr.ts to the supplied prd
  rr.ts <- rr.ts[prd,]

  # quality control -- NEED TO UPDATE THIS SECTION WITH MORE QC
    # replace all NA values with Raven missing value code
  rr.ts[is.na(rr.ts)] = -1.2345

  # write rvt files -----
  if (is.null(stnName)) {
    stnName <- sname
  }

  rvt.name <- sprintf("%s.rvt",stnName)
  if (met.prefix) {
    rvt.name <- sprintf('met_%s',rvt.name)
  }

  if (write.redirect) {
    fc.redirect <- file(rd.file,open='a+')
    writeLines(sprintf(':RedirectToFile %s',rvt.name),fc.redirect)
    close(fc.redirect)
  }

  if (write.stndata) {
    fc <- file(stndata.file,open='a+')
    writeLines(sprintf(':Gauge %s',stnName),fc)
    writeLines(sprintf('  :Latitude %.6f',lat),fc)
    writeLines(sprintf('  :Longitude %.6f',long),fc)
    writeLines(sprintf('  :Elevation %.2f',elev),fc)
    writeLines(sprintf('  :RedirectToFile %s',rvt.name),fc)
    writeLines(":EndGauge\n",fc)
    close(fc)
  }

  if (forcing.set == 1) {
    if (any(c(rr.ts[,tot.precip.ind],rr.ts[,max.temp.ind],rr.ts[,min.temp.ind])==-1.2345)) {
      warning("Missing values found in time series, post-processing will be required for use in Raven. Missing values written to file as -1.2345.")
    }
  } else if (forcing.set == 2) {
    if (any(c(rr.ts[,tot.rain.ind],rr.ts[,tot.snow.ind],rr.ts[,max.temp.ind],rr.ts[,min.temp.ind])==-1.2345)) {
      warning("Missing values found in time series, post-processing will be required for use in Raven. Missing values written to file as -1.2345.")
    }
  }

  # write main rvt file
  fc <- file(rvt.name,open='w+')
  writeLines(':MultiData',fc)
  writeLines(sprintf('%s 00:00:00 %g %i',as.character(lubridate::date(rr.ts[1])),timestep,nrow(rr.ts)),fc)
    # eventually update this to be based on a selection of custom-defined columns
  if (forcing.set == 1) {
    writeLines(':Parameters\tPRECIP\tTEMP_DAILY_MAX\tTEMP_DAILY_MIN',fc)
    writeLines(':Units\tmm/d\tC\tC',fc)
    for (j in 1:nrow(rr.ts)) {
      writeLines(sprintf('\t%g\t%g\t%g',rr.ts[j,tot.precip.ind],rr.ts[j,max.temp.ind],rr.ts[j,min.temp.ind]),fc)
    }
  } else if (forcing.set == 2) {
    writeLines(':Parameters\tRAINFALL\tSNOWFALL\tTEMP_DAILY_MAX\tTEMP_DAILY_MIN',fc)
    writeLines(':Units\tmm/d\tmm/d\tC\tC',fc)
    for (j in 1:nrow(rr.ts)) {
      writeLines(sprintf('\t%g\t%g\t%g\t%g',rr.ts[j,tot.rain.ind],rr.ts[j,tot.snow.ind],rr.ts[j,max.temp.ind],rr.ts[j,min.temp.ind]),fc)
    }
  } else {
    stop(sprintf("forcing.set %i not a defined option.",forcing.set))
  }
  writeLines(':EndMultiData',fc)
  close(fc)
  print(sprintf("Done writing to %s",rvt.name))
}

