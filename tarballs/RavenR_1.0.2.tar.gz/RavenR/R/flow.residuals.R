
# plots a residual time series, optionally smoothed
# optionally adds a horizontal line
# assumes units of cms
# accepts sim and obs as xts objects

# note that no title is added to the plot so that a title can be added afterwards, if
#   the plot is specific to a particular subbasin, location, iteration, etc.


flow.residuals <- function(sim,obs,ma.smooth=3,add.line=T,winter.shading=T) {

  if ( ma.smooth < 0) {
    stop("Requires a non-negative integer for ma.smooth ")
  }

  if  (ma.smooth == 0 ) {
    resids <- sim-obs
  } else {
    resids <- rollapply(sim-obs,ma.smooth,mean,fill=NA)
  }

  if (winter.shading) {
    plot(lubridate::date(resids),resids,xlab='Date',ylab='Smoothed Residuals',
         type='l',col='white',ylim=c(min(resids,na.rm=T),max(c(resids),na.rm=T)))
    # shaded winter months
    x <- resids
    temp <- x[((month(x[,1]) == 12) & (day(x[,1]) == 1)) | ((month(x[,1]) == 3) & (day(x[,1]) == 31))]
    ep <- match(lubridate::date(temp),lubridate::date(x))
    if (month(sim[ep[1]])==3) {
      ep <- ep[-1]
    }
    if (month(sim[ep[length(ep)]])==12) {
      ep <- ep[-length(ep)]
    }
    bc <- addColTrans('cyan',50)
    for (k in seq(1,length(ep),2)) {
      cord.x <- c(lubridate::date(x[ep[k]]),lubridate::date(x[ep[k]]),lubridate::date(x[ep[k+1]]),lubridate::date(x[ep[k+1]]))
      cord.y <- c(min(resids,na.rm=T),max(resids,na.rm=T),max(resids,na.rm=T),min(resids,na.rm=T))
      polygon(cord.x,cord.y,col=bc,border=NA)
    }
    lines(lubridate::date(resids),resids,col='black')
  } else {
    plot(lubridate::date(resids),resids,xlab='Date',ylab='Smoothed Residuals',
         type='l',col='black',ylim=c(min(resids,na.rm=T),max(c(resids),na.rm=T)))
  }
  if (add.line) {abline(h=0,col='blue',lty=5) }
}

